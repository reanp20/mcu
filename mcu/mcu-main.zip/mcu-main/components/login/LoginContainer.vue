<template>
  <div>
    <v-dialog v-model="isTerms" width="800">
      <v-card class="pa-10">
        <p></p>
        <p>
          Terms of Service of http://13.115.99.64/login
          MCU-IMPACTS&nbsp;(&quot;Us&quot; or &quot;We&quot;) provides
          the&nbsp;http://13.115.99.64/login/&nbsp;website and various related
          services (collectively, the &quot;Website&quot;) to you, the User,
          subject to your compliance with all the terms, conditions, and notices
          contained or referenced herein (the &quot;Terms of Service&quot;), as
          well as any other written agreement between us and you.
        </p>
        <p>
          In addition, when using particular services or materials on this
          Website, Users shall be subject to any posted rules applicable to such
          services or materials that may contain terms and conditions in
          addition to those in these Terms of Service. All such guidelines or
          rules are hereby incorporated by reference into these Terms of
          Service.
        </p>
        <p>
          These Terms of Service are effective as of&nbsp;January 11, 2023 We
          expressly reserve the right to change these Terms of Service from time
          to time without notice to you. You acknowledge and agree that it is
          your responsibility to review this Website and these Terms of Service
          from time to time and to familiarize yourself with any modifications.
        </p>
        <p>
          Your continued use of this Website after such modifications will
          constitute acknowledgement of the modified Terms of Service and
          agreement to abide and be bound by the modified Terms of Service.
        </p>
        <p>
          We reserve the sole right to either modify or discontinue the Website,
          including any of the Website&rsquo;s features, at any time with or
          without notice to you. We will not be liable to you or any third party
          should we exercise such right. Any new features that augment or
          enhance the then-current services on this Website shall also be
          subject to these Terms of Service. This Terms of Service was created
          by
          <a href="https://www.termsservicetemplate.com/"
            >Terms Service Template Generator</a
          >.
        </p>
        <p>Conduct on Website</p>
        <p>
          Your use of the Website is subject to all applicable laws and
          regulations, and you are solely responsible for the substance of your
          communications through the Website. By posting information in or
          otherwise using any communications service, chat room, message board,
          newsgroup, software library, or other interactive service that may be
          available to you on or through this Website, you agree that you will
          not upload, share, post, or otherwise distribute or facilitate
          distribution of any content &mdash; including text, communications,
          software, images, sounds, data, or other information &mdash; that:
        </p>
        <ul>
          <li>
            Is unlawful, threatening, abusive, harassing, defamatory, libelous,
            deceptive, fraudulent, invasive of another&rsquo;s privacy,
            tortious, contains explicit or graphic descriptions or accounts of
            sexual acts (including but not limited to sexual language of a
            violent or threatening nature directed at another individual or
            group of individuals), or otherwise violates our rules or policies
          </li>
          <li>
            Victimizes, harasses, degrades, or intimidates an individual or
            group of individuals on the basis of religion, gender, sexual
            orientation, race, ethnicity, age, or disability
          </li>
          <li>
            Infringes on any patent, trademark, trade secret, copyright, right
            of publicity, or other proprietary right of any party
          </li>
          <li>
            Constitutes unauthorized or unsolicited advertising, junk or bulk
            email (also known as &quot;spamming&quot;), chain letters, any other
            form of unauthorized solicitation, or any form of lottery or
            gambling
          </li>
          <li>
            Contains software viruses or any other computer code, files, or
            programs that are designed or intended to disrupt, damage, or limit
            the functioning of any software, hardware, or telecommunications
            equipment or to damage or obtain unauthorized access to any data or
            other information of any third party
          </li>
          <li>
            Impersonates any person or entity, including any of our employees or
            representatives
          </li>
        </ul>
        <p>
          We neither endorse nor assume any liability for the contents of any
          material uploaded or submitted by third party users of the Website. We
          generally do not pre-screen, monitor, or edit the content posted by
          users of communications services, chat rooms, message boards,
          newsgroups, software libraries, or other interactive services that may
          be available on or through this Website. However, we and our agents
          have the right at their sole discretion to remove any content that, in
          our judgment, does not comply with these Terms of Service and any
          other rules of user conduct for our site, or is otherwise harmful,
          objectionable, or inaccurate. We are not responsible for any failure
          or delay in removing such content. You hereby consent to such removal
          and waive any claim against us arising out of such removal of content.
        </p>
        <p>
          You agree that we may at any time, and at our sole discretion,
          terminate your membership, account, or other affiliation with our site
          without prior notice to you for violating any of the above provisions.
          In addition, you acknowledge that we will cooperate fully with
          investigations of violations of systems or network security at other
          sites, including cooperating with law enforcement authorities in
          investigating suspected criminal violations.
        </p>
        <p>Third Party Websites</p>
        <p>
          This site may link you to other sites on the Internet or otherwise
          include references to information, documents, software, materials
          and/or services provided by other parties. These sites may contain
          information or material that some people may find inappropriate or
          offensive.
        </p>
        <p>
          These other sites and parties are not under our control, and you
          acknowledge that we are not responsible for the accuracy, copyright
          compliance, legality, decency, or any other aspect of the content of
          such sites, nor are we responsible for errors or omissions in any
          references to other parties or their products and services. The
          inclusion of such a link or reference is provided merely as a
          convenience and does not imply endorsement of, or association with,
          the Website or party by us, or any warranty of any kind, either
          express or implied.
        </p>
        <p>Intellectual Property</p>
        <p>
          All custom graphics, icons, logos, and service names used on the
          Website are registered trademarks, service marks, and/or artwork held
          under copyright of&nbsp;MCU-IMPACTS&nbsp;or its Affiliates. All other
          marks are property of their respective owners. Nothing in these Terms
          of Service grants you any right to use any trademark, service mark,
          logo, and/or the name or trade names of&nbsp;MCU-IMPACTS&nbsp;or its
          Affiliates.
        </p>
        <p>Disclaimer of Warranties</p>
        <p>
          Content available through this Website often represents the opinions
          and judgments of an information provider, site user, or other person
          or entity not connected with us. We do not endorse, nor are we
          responsible for the accuracy or reliability of, any opinion, advice,
          or statement made by anyone other than an
          authorized&nbsp;MCU-IMPACTS&nbsp;spokesperson speaking in his/her
          official capacity. Please refer to the specific editorial policies
          posted on various sections of this Website for further information,
          which policies are incorporated by reference into these Terms of
          Service.
        </p>
        <p>
          You understand and agree that temporary interruptions of the services
          available through this Website may occur as normal events. You further
          understand and agree that we have no control over third party networks
          you may access in the course of the use of this Website, and
          therefore, delays and disruption of other network transmissions are
          completely beyond our control.
        </p>
        <p>
          You understand and agree that the services available on this Website
          are provided &quot;AS IS&quot; and that we assume no responsibility
          for the timeliness, deletion, mis-delivery or failure to store any
          user communications or personalization settings.
        </p>
        <p>International Use</p>
        <p>
          Although this Website may be accessible worldwide, we make no
          representation that materials on this Website are appropriate or
          available for use in locations outside the United States, and
          accessing them from territories where their contents are illegal is
          prohibited. Those who choose to access this Website from other
          locations do so on their own initiative and are responsible for
          compliance with local laws. Any offer for any product, service, and/or
          information made in connection with this Website is void where
          prohibited.
        </p>
        <p>Termination</p>
        <p>
          You agree that we may, in our sole discretion, terminate or suspend
          your access to all or part of the Website with or without notice and
          for any reason, including, without limitation, breach of these Terms
          of Service. Any suspected fraudulent, abusive or illegal activity may
          be grounds for terminating your relationship and may be referred to
          appropriate law enforcement authorities.
        </p>
        <p>
          Upon termination or suspension, regardless of the reasons therefore,
          your right to use the services available on this Website immediately
          ceases, and you acknowledge and agree that we may immediately
          deactivate or delete your account and all related information and
          files in your account and/or bar any further access to such files or
          this Website. We shall not be liable to you or any third party for any
          claims or damages arising out of any termination or suspension or any
          other actions taken by us in connection with such termination or
          suspension.
        </p>
        <p>Governing Law</p>
        <p>
          These Terms of Service and any dispute or claim arising out of, or
          related to them, shall be governed by and construed in accordance with
          the internal laws of the&nbsp;ph&nbsp;without giving effect to any
          choice or conflict of law provision or rule.
        </p>
        <p>
          Any legal suit, action or proceeding arising out of, or related to,
          these Terms of Service or the Website shall be instituted exclusively
          in the federal courts of ph.
        </p>
        <v-row>
          <v-col>
            <v-btn
              depressed
              color="black"
              dark
              @click="cancelTerm"
              :loading="isLoaded"
            >
              Cancel
            </v-btn>
          </v-col>
          <v-col>
            <div>
              <v-btn
                depressed
                color="#7c0ba0"
                dark
                @click="submitHandlerRegister"
                :loading="isLoaded"
              >
                Submit
              </v-btn>
            </div>
          </v-col>
        </v-row>
      </v-card>
    </v-dialog>
    <v-snackbar
      top
      absolute
      bottom
      color="error"
      outlined
      centered
      v-model="snackbar"
    >
      Wrong Credentials
      <template v-slot:action="{ attrs }">
        <v-btn color="red" text v-bind="attrs" @click="snackbar = false">
          Close
        </v-btn>
      </template>
    </v-snackbar>
    <v-snackbar
      top
      absolute
      bottom
      color="error"
      outlined
      centered
      v-model="snackbarisVerified"
    >
      Not yet verified. Please check your email. Thank you!
      <template v-slot:action="{ attrs }">
        <v-btn
          color="red"
          text
          v-bind="attrs"
          @click="snackbarisVerified = false"
        >
          Close
        </v-btn>
      </template>
    </v-snackbar>

    <v-card
      height="700"
      :style="category == 'register' ? 'overflow:scroll' : ''"
      width="700"
      class="rounded-xl"
      elevation="12"
    >
      <div
        style="background-color: #7c0ba0; color: white"
        align="center"
        class="pa-5"
      >
        Login Form
      </div>
      <div
        align="start"
        class="pa-5"
        v-if="category != 'login'"
        @click="category = 'login'"
        style="cursor: pointer"
      >
        <v-icon color="black">mdi-arrow-left</v-icon>
      </div>
      <div class="pt-5">
        <v-img src="/mcu_sealed.png" height="150" width="150" contain> </v-img>
        <div align="center" v-if="category == 'forgot-password'">
          To reset your password,submit your email address below.
        </div>
      </div>
      <div class="pa-5" align="start">
        <div v-if="category == 'register'" class="pb-10">
          To continue with your registration, kindly complete the form.
          <div class="text-h6 pt-5">
            <b> Search by email address</b>
          </div>
        </div>
        <v-row>
          <v-col v-if="!isOTP">
            <div>Email</div>
            <div>
              <v-text-field
                hide-details=""
                append-icon="mdi-account"
                outlined
                v-model="register.email"
              ></v-text-field>
            </div>
          </v-col>
          <v-col cols="12" v-if="category == 'register'">
            <div>Student Number</div>
            <div>
              <v-text-field
                hide-details=""
                append-icon="mdi-account"
                outlined
                v-model="register.student_number"
              ></v-text-field>
            </div>
          </v-col>
          <v-col cols="12" v-if="category == 'register'">
            <div>Firstname</div>
            <div>
              <v-text-field
                hide-details=""
                append-icon="mdi-account"
                outlined
                v-model="register.firstname"
              ></v-text-field>
            </div>
          </v-col>
          <v-col cols="12" v-if="category == 'register'">
            <div>Lastname</div>
            <div>
              <v-text-field
                hide-details=""
                append-icon="mdi-account"
                outlined
                v-model="register.lastname"
              ></v-text-field>
            </div>
          </v-col>
          <v-col cols="12" v-if="category == 'register'">
            <div>Middle Initial</div>
            <div>
              <v-text-field
                hide-details=""
                append-icon="mdi-account"
                outlined
                v-model="register.middlename"
              ></v-text-field>
            </div>
          </v-col>
          <v-col cols="12" v-if="category == 'register'">
            <div>Year Graduated</div>
            <div>
              <v-text-field
                hide-details=""
                append-icon="mdi-account"
                outlined
                v-model="register.last_attended"
              ></v-text-field>
            </div>
          </v-col>
          <v-col cols="12" v-if="category == 'register'">
            <div>Mobile Number</div>
            <div>
              <v-row>
                <v-col cols="auto" class="pr-0">
                  <div style="width: 120px">
                    <v-select
                      outlined
                      dense
                      hide-details=""
                      v-model="register.coutry_code"
                      :items="[
                        '+63',
                        '+93',
                        '+355',
                        '+213',
                        '+1684',
                        '+376',
                        '+244',
                        '+1264',
                        '+672',
                        '+64',
                        '+1268',
                        '+54',
                        '+374',
                        '+297',
                        '+247',
                        '+61',
                        '+43',
                        '+994',
                        '+1242',
                        '+973',
                        '+880',
                        '+1246',
                        '+375',
                        '+32',
                        '+501',
                        '+229',
                        '+1441',
                        '+975',
                        '+591',
                        '+387',
                        '+267',
                        '+55',
                        '+1284',
                        '+673',
                        '+359',
                        '+226',
                        '+95',
                        '+257',
                        '+855',
                        '+237',
                        '+1',
                        '+238',
                        '+1345',
                        '+236',
                        '+235',
                        '+56',
                        '+86',
                        '+61',
                        '+57',
                        '+269',
                        '+242',
                        '+682',
                      ]"
                    >
                    </v-select>
                  </div>
                </v-col>
                <v-col>
                  <v-text-field
                    outlined
                    type="number"
                    placeholder=""
                    dense
                    v-model="register.mobile_number"
                  ></v-text-field>
                </v-col>
              </v-row>
            </div>
          </v-col>

          <div class="pl-4" v-if="category == 'register'">Working Status</div>
          <v-radio-group
            v-model="register.work_status"
            v-if="category == 'register'"
          >
            <v-radio label="Employed" value="Employed"></v-radio>
            <v-radio label="Unemployed" value="Unemployed"></v-radio>
            <v-radio label="Self Employed" value="Self Employed"></v-radio>
          </v-radio-group>
          <v-col cols="12" v-if="isOTP">
            <div>OTP</div>
            <div>
              <v-text-field outlined v-model="register.otp"></v-text-field>
            </div>
          </v-col>
          <v-col cols="12" v-else-if="category != 'forgot-password'">
            <div>Password</div>
            <div>
              <v-text-field
                :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
                @click:append="show1 = !show1"
                outlined
                v-model="register.password"
                :type="show1 ? 'text' : 'password'"
              ></v-text-field>
            </div>
            <div>
              <v-row v-if="category == 'login'">
                <v-col>
                  <b style="cursor: pointer" @click="category = 'register'">
                    Register Now</b
                  >
                </v-col>
                <v-col
                  @click="category = 'forgot-password'"
                  align-self="center"
                  align="end"
                >
                  <b style="cursor: pointer"> Forgot Password?</b>
                </v-col>
              </v-row>
            </div>
          </v-col>
        </v-row>

        <div align="center" class="pt-10" v-if="category == 'login'">
          <v-btn
            depressed
            color="#7c0ba0"
            dark
            @click="submitHandler"
            :loading="isLoaded"
          >
            Login
          </v-btn>
        </div>
        <div v-if="category == 'forgot-password'" align="center" class="pt-10">
          <v-btn
            depressed
            color="#7c0ba0"
            dark
            @click="resetPass"
            :loading="isLoaded"
          >
            Send
          </v-btn>
        </div>
        <!-- <div @click="isTerms = true" class="pointer">Terms and Conditions</div> -->
        <div v-if="category == 'register'" align="center" class="pt-10">
          <v-btn
            depressed
            color="#7c0ba0"
            dark
            @click="isTerms = true"
            :loading="isLoaded"
          >
            Submit
          </v-btn>
        </div>
        <div v-if="category == 'register'" align="center" class="py-10">
          Please wait for Program head approval on your account
        </div>
      </div>
    </v-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isTerms: false,
      otpValue: "",
      isOTP: false,
      show1: false,
      category: "login",
      snackbar: false,
      img_holder: "image_placeholder.png",
      image: "",
      url: "",
      users: [],
      isLoaded: false,
      register: {},
      snackbarisVerified: false,
    };
  },
  methods: {
    cancelTerm() {
      location.reload();
    },
    resetPass() {
      this.$store
        .dispatch("reset/add", { email: this.register.email })
        .then((res) => {
          alert("Successfully Sent!");
        });
    },
    sendOtp() {
      if (this.isOTP) {
        if (this.otpValue == this.register.otp) {
          this.submitHandler();
        } else {
          alert("Wrong OTP");
        }

        return;
      } else {
        this.otpValue = Math.random().toString(6).slice(2);
        this.$store
          .dispatch("users/otp", {
            email: this.register.email,
            code: this.otpValue,
          })
          .then((res) => {
            alert("OTP code sent to your email");
            this.isOTP = true;
          });
      }
    },
    async submitHandlerRegister() {
      if (this.register.email == "" || this.register.email == undefined) {
        alert("Email field is required.");
        return;
      }
      if (
        this.register.student_number == "" ||
        this.register.student_number == undefined
      ) {
        alert("Student Number field is required.");
        return;
      }
      if (
        this.register.firstname == "" ||
        this.register.firstname == undefined
      ) {
        alert("Firstname field is required.");
        return;
      }
      if (this.register.lastname == "" || this.register.lastname == undefined) {
        alert("Lastname field is required.");
        return;
      }
      if (
        this.register.middlename == "" ||
        this.register.middlename == undefined
      ) {
        alert("Middle Name field is required.");
        return;
      }
      if (
        this.register.last_attended == "" ||
        this.register.last_attended == undefined
      ) {
        alert("Year graduated field is required.");
        return;
      }
      if (
        this.register.mobile_number == "" ||
        this.register.mobile_number == undefined
      ) {
        alert("Mobile Number field is required.");
        return;
      }
      if (
        this.register.work_status == "" ||
        this.register.work_status == undefined
      ) {
        alert("Work status field is required.");
        return;
      }
      this.isLoaded = true;
      // this.$refs.form.validate();
      // if (!this.isValid) return;
      // console.log(this.register);
      try {
        // this.register.password = "wew123WEW";
        this.register.account_type = "Student";
        this.register.is_active = false;
        await this.$store.dispatch("users/add", this.register);
        alert("Successful !");
        location = "/login";
      } catch (error) {
        alert(
          "Please make sure that the password is not related on the user`s details and the password must be at least 6 minimum character"
        );
        // alert(error)
      }
      this.isLoaded = false;
    },
    async submitHandler() {
      this.isLoaded = true;
      try {
        localStorage.setItem("password", this.register.password);
        const response = await this.$auth.loginWith("local", {
          data: this.register,
        });
      } catch (error) {
        alert("Wrong credentials");
        location.reload();
        this.isLoaded = false;
      }
    },
    //  async login() {
    //      if(this.users.email=='admin'){
    //          localStorage.setItem('account_type','admin')
    //          window.location.href="/admin/otp"

    //      }
    //      else if(this.users.email=='head'){
    //           localStorage.setItem('account_type','head')
    //          window.location.href="/dashboard"
    //      }
    //      else{
    //         localStorage.setItem('account_type','student')
    //          window.location.href="/student/dashboard"
    //      }
    //     //  window.location.href="dashboard"
    //   this.isLoaded = true;
    //   var credentials = {
    //     email: this.users.email,
    //     password: this.users.password,
    //   };
    //   try {
    //     var response = await this.$axios
    //       .post("login/", credentials)
    //       .then((response) => {
    //          if(response.data[0].status=='Deactivated'){
    //             alert("Your account is still deactivated. Please wait to approved by the admin.")
    //                this.isLoaded = false;
    //             return
    //           }
    //         if(response.data=='no_data'){
    //             alert('Wrong Credentials')
    //             this.isLoaded=false;
    //             return
    //         }
    //         console.log(response.data)
    //         localStorage.setItem("id", response.data[0].id);
    //         localStorage.setItem("account_type", response.data[0].account_type);
    //         // console.log(response)
    //         if(response.data[0].account_type=='Admin'){
    //             window.location.href="/admin/dashboard"
    //         }
    //         else{

    //             window.location.href="/artist/design"
    //         }

    //         // const users = this.$axios
    //         //   .get(`/users/details/`, {
    //         //     headers: {
    //         //       Authorization: `Bearer ${localStorage.getItem("token")}`,
    //         //     },
    //         //   })
    //         //   .then((users) => {
    //         //     // if(!users.data.is_verified){
    //         //     //   this.snackbarisVerified = true
    //         //     //   this.isLoaded=false
    //         //     //   return
    //         //     // }
    //         //     localStorage.setItem("id", users.data.id);
    //         //     localStorage.setItem("middlename", users.data.middlename);
    //         //     localStorage.setItem("firstname", users.data.firstname);
    //         //     localStorage.setItem("lastname", users.data.lastname);
    //         //     localStorage.setItem("account_type",users.data.account_type)
    //         //     if(users.data.account_type=='Client'){
    //         //       window.location.href="/beneficiaries"
    //         //     }
    //         //     else{
    //         //         window.location.href="/admin/dashboard"
    //         //     }
    //         //     this.isLoaded = false;

    //         //     // if(users.data.is_superuser) window.location.href = "/home";
    //         //     // else window.location.href = "/home";
    //         //   });
    //       });

    //   } catch (error) {
    //     this.snackbar = true;
    //     this.isLoaded = false;
    //   }
    // },
    onFileUpload(e) {
      this.image = e;
      e = e.target.files[0];
      if (e["name"].length > 100) {
        alert("255 characters exceeded filename.");
        return;
      }
      try {
        if (e.size > 16000000) {
          alert("Only 15mb file can be accepted.");
          return;
        }
      } catch (error) {
        alert(error);
        return;
      }
      this.image = e;
      if (e == null) {
      } else {
        this.url, (this.img_holder = URL.createObjectURL(e));
      }
    },
  },
};
</script>

<style>
</style>