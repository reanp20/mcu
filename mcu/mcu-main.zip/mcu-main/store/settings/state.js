const state = () => ({
    page_size: 10,
    query_results: {},
    settings_data: [],
  });
  
  export default state;
  