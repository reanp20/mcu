<template>
    <v-img src="/bglogin.png" align="center" class="d-flex justify-center align-center" width="100vw" height="130vh"  >
       <login-container />
    </v-img>
</template>

<script>
import LoginContainer from '../../components/login/LoginContainer.vue'
export default {
  components: { LoginContainer },
  
}
</script>

<style>

</style>