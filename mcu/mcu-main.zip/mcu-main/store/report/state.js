const state = () => ({
    page_size: 10,
    query_results: {},
    report_data: [],
  });
  
  export default state;
  