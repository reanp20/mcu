<template>
  <div>
      <request-container />
  </div>
</template>

<script>
import RequestContainer from '../../../components/head/request/RequestContainer.vue'
export default {
  components: { RequestContainer },

}
</script>

<style>

</style>