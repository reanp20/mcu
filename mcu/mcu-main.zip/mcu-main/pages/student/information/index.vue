<template>
  <div>
      <information-container />
  </div>
</template>

<script>
import InformationContainer from '../../../components/students/Information/InformationContainer.vue'
export default {
    components:{
        InformationContainer
    }
}
</script>

<style>

</style>
