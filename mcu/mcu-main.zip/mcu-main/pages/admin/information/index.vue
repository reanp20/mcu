<template>
  <div>
      <information-container />
  </div>
</template>

<script>
import InformationContainer from '../../../components/admin/information/InformationContainer.vue'
export default {
  components: { InformationContainer },

}
</script>

<style>

</style>