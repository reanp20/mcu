const mutations = {
    SET_EVENT: (state, payload) => {
    state.event_data = payload;
  },
}
  export default mutations;
  