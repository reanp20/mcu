const mutations = {
    SET_EVENT: (state, payload) => {
    state.job_posting_data = payload;
  },
}
  export default mutations;
  