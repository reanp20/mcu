<template>
  <div>
      <announcement-container />
  </div>
</template>

<script>
import AnnouncementContainer from '../../../components/head/announcement/AnnouncementContainer.vue'
export default {
  components: { AnnouncementContainer },

}
</script>

<style>

</style>