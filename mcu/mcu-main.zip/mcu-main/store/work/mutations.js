const mutations = {
    SET_EVENT: (state, payload) => {
    state.work_data = payload;
  },
}
  export default mutations;
  