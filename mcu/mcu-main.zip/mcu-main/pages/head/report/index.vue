<template>
  <div>
      <report-container />
  </div>
</template>

<script>
import ReportContainer from '../../../components/head/report/ReportContainer.vue'
export default {
    components:{
        ReportContainer
    }
}
</script>

<style>

</style>
