const state = () => ({
    page_size: 10,
    query_results: {},
    event_data: [],
  });
  
  export default state;
  