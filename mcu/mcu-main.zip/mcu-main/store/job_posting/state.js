const state = () => ({
    page_size: 10,
    query_results: {},
    job_posting_data: [],
  });
  
  export default state;
  