const state = () => ({
    page_size: 10,
    query_results: {},
    announcement_data: [],
  });
  
  export default state;
  