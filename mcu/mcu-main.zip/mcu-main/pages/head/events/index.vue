<template>
  <div>
      <event-container />
  </div>
</template>

<script>
import EventContainer from '../../../components/head/events/EventContainer.vue'
export default {
    components:{
        EventContainer
    }
}
</script>

<style>


</style>