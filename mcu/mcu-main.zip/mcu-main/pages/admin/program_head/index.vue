<template>
  <div>
    <program-head-container />
  </div>
</template>

<script>
import ProgramHeadContainer from '../../../components/admin/program_head/ProgramHeadContainer.vue'
export default {
  components: { ProgramHeadContainer },

}
</script>

<style>

</style>