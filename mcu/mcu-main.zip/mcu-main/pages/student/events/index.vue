<template>
  <div>
      <event-container />
  </div>
</template>

<script>
import EventContainer from '../../../components/students/events/EventContainer.vue'
export default {
  components: { EventContainer },

}
</script>

<style>

</style>