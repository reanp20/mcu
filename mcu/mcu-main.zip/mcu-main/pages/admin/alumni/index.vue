<template>
  <div>
      <alumni-container />
  </div>
</template>

<script>
import AlumniContainer from '../../../components/admin/alumni/AlumniContainer.vue'
export default {
  components: { AlumniContainer },

}
</script>

<style>

</style>