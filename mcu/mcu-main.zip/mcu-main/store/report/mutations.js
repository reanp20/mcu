const mutations = {
    SET_EVENT: (state, payload) => {
    state.report_data = payload;
  },
}
  export default mutations;
  