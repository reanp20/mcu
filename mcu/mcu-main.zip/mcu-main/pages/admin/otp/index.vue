<template>
  <div>
      <otp-container />
  </div>
</template>

<script>
import OtpContainer from '../../../components/admin/otp/OtpContainer.vue'
export default {
  components: { OtpContainer },

}
</script>

<style>

</style>