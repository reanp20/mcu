<template>
  <div>
      <job-container />
  </div>
</template>

<script>
import JobContainer from '../../../components/students/job_posting/JobContainer.vue'
export default {
    components:{
        JobContainer
    }
}  
</script>

<style>

</style>
