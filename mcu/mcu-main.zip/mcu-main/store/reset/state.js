const state = () => ({
    page_size: 10,
    query_results: {},
    reset_data: [],
  });
  
  export default state;
  