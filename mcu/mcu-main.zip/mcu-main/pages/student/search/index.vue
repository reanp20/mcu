<template>
  <div>
    <search-container />
  </div>
</template>

<script>
import SearchContainer from '../../../components/students/search/SearchContainer.vue'
export default {
  components: { SearchContainer },

}
</script>

<style>

</style>