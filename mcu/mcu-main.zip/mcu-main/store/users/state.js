const state = () => ({
    page_size: 10,
    query_results: {},
    users: [],
    selected_customer: {},
  });
  
  export default state;
  