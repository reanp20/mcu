<template>
  <div>
      <dashboard-container />
  </div>
</template>

<script>
import DashboardContainer from '../../../components/admin/dashboard/DashboardContainer.vue'
export default {
  components: { DashboardContainer },

}
</script>

<style>

</style>