const state = () => ({
    page_size: 10,
    query_results: {},
    work_data: [],
  });
  
  export default state;
  