<template>
  <div>
      <announcement-container />
  </div>
</template>

<script>
import AnnouncementContainer from '../../../components/students/announcement/AnnouncementContainer.vue'
export default {
     components:{
         AnnouncementContainer
     }
}
</script>

<style>

</style>
